/* The site remains readable and navigable without JavaScript. */
const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('#primary-navigation');
if (toggle && nav) {
  document.documentElement.classList.add('js');
  const close = () => {
    toggle.setAttribute('aria-expanded', 'false');
    nav.classList.remove('is-open');
  };
  toggle.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') !== 'true';
    toggle.setAttribute('aria-expanded', String(open));
    nav.classList.toggle('is-open', open);
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
      close();
      toggle.focus();
    }
  });
  document.addEventListener('click', event => {
    if (!event.target.closest('.site-header')) close();
  });
  nav.querySelectorAll('a').forEach(link => link.addEventListener('click', close));
  window.matchMedia('(min-width: 961px)').addEventListener('change', close);
}

/* Preserve meaningful section anchors when changing language. */
const sharedAnchors = new Set(['join-us', 'news', 'approach', 'heterostructures', 'transport', 'light', 'facilities', 'contact']);
document.querySelectorAll('.language-switch a').forEach(link => {
  const updateAnchor = () => {
    const hash = window.location.hash;
    link.hash = sharedAnchors.has(hash.slice(1)) || hash.startsWith('#paper-') ? hash : '';
  };
  updateAnchor();
  link.addEventListener('click', updateAnchor);
});

/* Darken the photograph before the introduction reaches it. */
const story = document.querySelector('.scroll-story');
if (story) {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let pending = false;
  const paintStory = () => {
    pending = false;
    const box = story.getBoundingClientRect();
    const travel = Math.max(1, window.innerHeight * .38);
    const progress = Math.min(1, Math.max(0, (window.innerHeight * .35 - box.top) / travel));
    story.style.setProperty('--photo-dim', reducedMotion.matches ? '.72' : String(.18 + .58 * progress));
  };
  const requestPaint = () => {
    if (!pending) { pending = true; requestAnimationFrame(paintStory); }
  };
  window.addEventListener('scroll', requestPaint, { passive: true });
  window.addEventListener('resize', requestPaint);
  reducedMotion.addEventListener('change', requestPaint);
  paintStory();
}
