/* The site remains readable and navigable without JavaScript. */
const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('#primary-navigation');
if (toggle && nav) {
  document.documentElement.classList.add('js');
  const close = () => {
    toggle.setAttribute('aria-expanded', 'false');
    nav.classList.remove('is-open');
  };
  toggle.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') !== 'true';
    toggle.setAttribute('aria-expanded', String(open));
    nav.classList.toggle('is-open', open);
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
      close();
      toggle.focus();
    }
  });
  document.addEventListener('click', event => {
    if (!event.target.closest('.site-header')) close();
  });
  nav.querySelectorAll('a').forEach(link => link.addEventListener('click', close));
  window.matchMedia('(min-width: 961px)').addEventListener('change', close);
}

/* Preserve meaningful section anchors when changing language. */
const sharedAnchors = new Set(['join-us', 'news', 'approach', 'selected-results', 'heterostructures', 'transport', 'light', 'facilities', 'contact']);
document.querySelectorAll('.language-switch a').forEach(link => {
  const updateAnchor = () => {
    const hash = window.location.hash;
    link.hash = sharedAnchors.has(hash.slice(1)) || hash.startsWith('#paper-') || hash.startsWith('#result-') ? hash : '';
  };
  updateAnchor();
  link.addEventListener('click', updateAnchor);
});

/* A subtle darkening as the Home photograph leaves the viewport. */
const story = document.querySelector('.scroll-story');
if (story) {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let pending = false;
  const paintStory = () => {
    pending = false;
    const box = story.getBoundingClientRect();
    const travel = Math.max(1, window.innerHeight * .38);
    const progress = Math.min(1, Math.max(0, -box.top / travel));
    story.style.setProperty('--photo-dim', reducedMotion.matches ? '.18' : String(.18 + .35 * progress));
  };
  const requestPaint = () => {
    if (!pending) { pending = true; requestAnimationFrame(paintStory); }
  };
  window.addEventListener('scroll', requestPaint, { passive: true });
  window.addEventListener('resize', requestPaint);
  reducedMotion.addEventListener('change', requestPaint);
  paintStory();
}

/* Open the specific result linked from a Home card; the rest stay collapsed. */
const revealLinkedResult = () => {
  if (!window.location.hash.startsWith('#result-')) return;
  const result = document.getElementById(window.location.hash.slice(1));
  const disclosure = result?.querySelector('details.result-disclosure');
  if (disclosure) disclosure.open = true;
};
revealLinkedResult();
window.addEventListener('hashchange', revealLinkedResult);
